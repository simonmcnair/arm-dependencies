/*
    MakeMKV GUI - Graphics user interface application for MakeMKV

    Written by GuinpinSoft inc <makemkvgui@makemkv.com>

    This file is hereby placed into public domain,
    no copyright is claimed.

*/
#ifndef VERNUM_H_INCLUDED
#define VERNUM_H_INCLUDED

#define MAKEMKV_VERSION_NUMBER  "v1.17.7"
#define LIBMMBD_VERSION_NUMBER  "v1.8.0"
#define WINCDARB_VERSION_NUMBER "v1.2.0"

#endif // VERNUM_H_INCLUDED

